package com.example.app9;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    View countriesLayout, leadersLayout, museumsLayout, wondersLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            return insets;
        });

        View header = findViewById(R.id.headerTitle);
        ViewCompat.setOnApplyWindowInsetsListener(header, (v, insets) -> {
            int topInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top;

            // Set padding top cho header để không bị che
            v.setPadding(0, topInset + 16, 0, 16);

            return insets;
        });

        // Gán view
        countriesLayout = findViewById(R.id.cardCountries);
        leadersLayout = findViewById(R.id.cardLeaders);
        museumsLayout = findViewById(R.id.cardMuseums);
        wondersLayout = findViewById(R.id.cardWonders);

        // Gán sự kiện click
        countriesLayout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, countries.class);
            startActivity(intent);
        });

        leadersLayout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, leaders.class);
            startActivity(intent);
        });

        museumsLayout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Museums.class);
            startActivity(intent);
        });

        wondersLayout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, wonderofworld.class);
            startActivity(intent);
        });
    }
}
