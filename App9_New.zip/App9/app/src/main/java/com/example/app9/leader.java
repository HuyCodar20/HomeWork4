package com.example.app9;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link leader#newInstance} factory method to
 * create an instance of this fragment.
 */
public class leader extends Fragment {

    private static final String ARG_LEADER_NAME = "leader_name";
    private String leaderName;

    public leader() {
        // Required empty public constructor
    }

    public static leader newInstance(String leaderName) {
        leader fragment = new leader();
        Bundle args = new Bundle();
        args.putString(ARG_LEADER_NAME, leaderName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            leaderName = getArguments().getString(ARG_LEADER_NAME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_country, container, false);

        ProgressBar progressBar = view.findViewById(R.id.progressBar);
        ImageView imgFlag = view.findViewById(R.id.imgFlag);
        TextView txtCapital = view.findViewById(R.id.txtCapital);
        TextView txtLargestCity = view.findViewById(R.id.txtLargestCity);
        TextView txtLanguage = view.findViewById(R.id.txtLanguage);
        TextView txtArea = view.findViewById(R.id.txtArea);
        TextView txtCurrency = view.findViewById(R.id.txtCurrency);
        TextView txtDescription = view.findViewById(R.id.txtDescription);

        progressBar.setVisibility(View.VISIBLE);

        new Handler().postDelayed(() -> {
            progressBar.setVisibility(View.GONE);

            if (leaderName.equals("leader1")) {
                imgFlag.setImageResource(R.drawable.trump); // Hình Donald Trump
                txtCapital.setText("Name: Donald Trump");
                txtLargestCity.setText("Born: 1946");
                txtLanguage.setText("Country: United States");
                txtArea.setText("Position: President");
                txtCurrency.setText("Period: 2017 - 2021");
                txtDescription.setText("Donald Trump served as the 45th President of the United States, known for his unconventional policies and business-oriented leadership.");
            } else if (leaderName.equals("leader2")) {
                imgFlag.setImageResource(R.drawable.putin); // Hình Vladimir Putin
                txtCapital.setText("Name: Vladimir Putin");
                txtLargestCity.setText("Born: 1952");
                txtLanguage.setText("Country: Russia");
                txtArea.setText("Position: President");
                txtCurrency.setText("Period: 2000 - Present");
                txtDescription.setText("Vladimir Putin has been the President of Russia for multiple terms, known for his strong leadership and influence on global politics.");
            } else if (leaderName.equals("leader3")) {
                imgFlag.setImageResource(R.drawable.tcbinh); // Hình Tập Cận Bình
                txtCapital.setText("Name: Xi Jinping");
                txtLargestCity.setText("Born: 1953");
                txtLanguage.setText("Country: China");
                txtArea.setText("Position: General Secretary");
                txtCurrency.setText("Period: 2012 - Present");
                txtDescription.setText("Xi Jinping is the General Secretary of the Communist Party of China, known for his anti-corruption campaign and strong central leadership.");
            }

        }, 1500);

        return view;
    }
}
