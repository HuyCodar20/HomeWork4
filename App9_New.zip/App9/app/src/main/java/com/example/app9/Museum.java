package com.example.app9;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Museum extends Fragment {

    private static final String ARG_MUSEUM_NAME = "museum_name";
    private String museumName;

    public Museum() {
        // Required empty public constructor
    }

    public static Museum newInstance(String museumName) {
        Museum fragment = new Museum();
        Bundle args = new Bundle();
        args.putString(ARG_MUSEUM_NAME, museumName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            museumName = getArguments().getString(ARG_MUSEUM_NAME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_country, container, false);

        ProgressBar progressBar = view.findViewById(R.id.progressBar);
        ImageView imgFlag = view.findViewById(R.id.imgFlag);
        TextView txtCapital = view.findViewById(R.id.txtCapital);
        TextView txtLargestCity = view.findViewById(R.id.txtLargestCity);
        TextView txtLanguage = view.findViewById(R.id.txtLanguage);
        TextView txtArea = view.findViewById(R.id.txtArea);
        TextView txtCurrency = view.findViewById(R.id.txtCurrency);
        TextView txtDescription = view.findViewById(R.id.txtDescription);

        progressBar.setVisibility(View.VISIBLE);

        new Handler().postDelayed(() -> {
            progressBar.setVisibility(View.GONE);

            if (museumName.equals("louvre")) {
                imgFlag.setImageResource(R.drawable.louvre);
                txtCapital.setText("Name: Louvre Museum");
                txtLargestCity.setText("Location: Paris, France");
                txtLanguage.setText("Established: 1793");
                txtArea.setText("Area: 72,735 m²");
                txtCurrency.setText("Famous for: Mona Lisa");
                txtDescription.setText("The Louvre is the world's largest art museum and a historic monument in Paris, France.");
            } else if (museumName.equals("british")) {
                imgFlag.setImageResource(R.drawable.british);
                txtCapital.setText("Name: British Museum");
                txtLargestCity.setText("Location: London, UK");
                txtLanguage.setText("Established: 1753");
                txtArea.setText("Area: 92,000 m²");
                txtCurrency.setText("Famous for: Rosetta Stone");
                txtDescription.setText("The British Museum is dedicated to human history, art and culture, located in London.");
            } else if (museumName.equals("metropolitan")) {
                imgFlag.setImageResource(R.drawable.metropolitan);
                txtCapital.setText("Name: Metropolitan Museum");
                txtLargestCity.setText("Location: New York, USA");
                txtLanguage.setText("Established: 1870");
                txtArea.setText("Area: 190,000 m²");
                txtCurrency.setText("Famous for: The Temple of Dendur");
                txtDescription.setText("The Metropolitan Museum of Art is the largest art museum in the United States.");
            }

        }, 1500);

        return view;
    }
}
