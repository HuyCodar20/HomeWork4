package com.example.app9;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class LeaderPagerAdapter extends FragmentStateAdapter {

    public LeaderPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return leader.newInstance("leader1");
            case 1:
                return leader.newInstance("leader2");
            case 2:
                return leader.newInstance("leader3");
            default:
                return leader.newInstance("leader1");
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
