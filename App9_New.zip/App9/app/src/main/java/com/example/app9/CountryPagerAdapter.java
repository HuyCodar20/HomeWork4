package com.example.app9;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class CountryPagerAdapter extends FragmentStateAdapter {

    public CountryPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return CountryFragment.newInstance("uk");
            case 1:
                return CountryFragment.newInstance("italy");
            case 2:
                return CountryFragment.newInstance("france");
            default:
                return CountryFragment.newInstance("uk");
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
