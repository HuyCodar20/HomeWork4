package com.example.app9;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class CountryFragment extends Fragment {

    private static final String ARG_COUNTRY = "country";

    private String country;

    public static CountryFragment newInstance(String country) {
        CountryFragment fragment = new CountryFragment();
        Bundle args = new Bundle();
        args.putString(ARG_COUNTRY, country);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            country = getArguments().getString(ARG_COUNTRY);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_country, container, false);

        ProgressBar progressBar = view.findViewById(R.id.progressBar);
        ImageView imgFlag = view.findViewById(R.id.imgFlag);
        TextView txtCapital = view.findViewById(R.id.txtCapital);
        TextView txtLargestCity = view.findViewById(R.id.txtLargestCity);
        TextView txtLanguage = view.findViewById(R.id.txtLanguage);
        TextView txtArea = view.findViewById(R.id.txtArea);
        TextView txtCurrency = view.findViewById(R.id.txtCurrency);
        TextView txtDescription = view.findViewById(R.id.txtDescription);

        progressBar.setVisibility(View.VISIBLE);

        // Delay 1.5 giây để tạo hiệu ứng loading
        new Handler().postDelayed(() -> {
            progressBar.setVisibility(View.GONE);

            if (country.equals("uk")) {
                imgFlag.setImageResource(R.drawable.englandflag);
                txtCapital.setText(getString(R.string.label_capital) + " London");
                txtLargestCity.setText(getString(R.string.label_largest_city) + " London");
                txtLanguage.setText(getString(R.string.label_language) + " English");
                txtArea.setText(getString(R.string.label_area) + " 243,610 km²");
                txtCurrency.setText(getString(R.string.label_currency) + " Pound sterling");
                txtDescription.setText("The United Kingdom is an island nation in northwestern Europe...");
            } else if (country.equals("italy")) {
                imgFlag.setImageResource(R.drawable.italyflag);
                txtCapital.setText(getString(R.string.label_capital) + " Rome");
                txtLargestCity.setText(getString(R.string.label_largest_city) + " Rome");
                txtLanguage.setText(getString(R.string.label_language) + " Italian");
                txtArea.setText(getString(R.string.label_area) + " 301,340 km²");
                txtCurrency.setText(getString(R.string.label_currency) + " Euro");
                txtDescription.setText("Italy is a European country with a long Mediterranean coastline...");
            } else if (country.equals("france")) {
                imgFlag.setImageResource(R.drawable.franceflag);
                txtCapital.setText(getString(R.string.label_capital) + " Paris");
                txtLargestCity.setText(getString(R.string.label_largest_city) + " Paris");
                txtLanguage.setText(getString(R.string.label_language) + " French");
                txtArea.setText(getString(R.string.label_area) + " 551,695 km²");
                txtCurrency.setText(getString(R.string.label_currency) + " Euro");
                txtDescription.setText("France, in Western Europe, encompasses medieval cities, alpine villages, and Mediterranean beaches...");
            }

        }, 1500); // Delay 1.5s

        return view;
    }
}
