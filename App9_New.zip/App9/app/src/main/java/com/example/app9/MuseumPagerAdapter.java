package com.example.app9;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class MuseumPagerAdapter extends FragmentStateAdapter {

    public MuseumPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return Museum.newInstance("louvre");
            case 1:
                return Museum.newInstance("british");
            case 2:
                return Museum.newInstance("metropolitan");
            default:
                return Museum.newInstance("louvre");
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
