package com.example.app9;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class WonderPagerAdapter extends FragmentStateAdapter {

    public WonderPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return wonderofworlds.newInstance("greatwall");
            case 1:
                return wonderofworlds.newInstance("petra");
            case 2:
                return wonderofworlds.newInstance("colosseum");
            default:
                return wonderofworlds.newInstance("greatwall");
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
