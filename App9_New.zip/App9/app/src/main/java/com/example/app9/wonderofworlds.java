package com.example.app9;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class wonderofworlds extends Fragment {

    private static final String ARG_WONDER_NAME = "wonder_name";
    private String wonderName;

    public wonderofworlds() {
        // Required empty public constructor
    }

    public static wonderofworlds newInstance(String wonderName) {
        wonderofworlds fragment = new wonderofworlds();
        Bundle args = new Bundle();
        args.putString(ARG_WONDER_NAME, wonderName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            wonderName = getArguments().getString(ARG_WONDER_NAME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_country, container, false);

        ProgressBar progressBar = view.findViewById(R.id.progressBar);
        ImageView imgFlag = view.findViewById(R.id.imgFlag);
        TextView txtCapital = view.findViewById(R.id.txtCapital);
        TextView txtLargestCity = view.findViewById(R.id.txtLargestCity);
        TextView txtLanguage = view.findViewById(R.id.txtLanguage);
        TextView txtArea = view.findViewById(R.id.txtArea);
        TextView txtCurrency = view.findViewById(R.id.txtCurrency);
        TextView txtDescription = view.findViewById(R.id.txtDescription);

        progressBar.setVisibility(View.VISIBLE);

        new Handler().postDelayed(() -> {
            progressBar.setVisibility(View.GONE);

            if (wonderName.equals("greatwall")) {
                imgFlag.setImageResource(R.drawable.greetwall);
                txtCapital.setText("Name: Great Wall of China");
                txtLargestCity.setText("Location: China");
                txtLanguage.setText("Built: 7th century BC");
                txtArea.setText("Length: ~21,196 km");
                txtCurrency.setText("Type: Fortification");
                txtDescription.setText("The Great Wall of China is a series of fortifications made of stone, brick, and other materials.");
            } else if (wonderName.equals("petra")) {
                imgFlag.setImageResource(R.drawable.petra);
                txtCapital.setText("Name: Petra");
                txtLargestCity.setText("Location: Jordan");
                txtLanguage.setText("Built: 5th century BC");
                txtArea.setText("Type: Rock-cut architecture");
                txtCurrency.setText("Type: Historical city");
                txtDescription.setText("Petra is famous for its rock-cut architecture and water conduit system. It is also called the 'Rose City'.");
            } else if (wonderName.equals("colosseum")) {
                imgFlag.setImageResource(R.drawable.colosseum);
                txtCapital.setText("Name: Colosseum");
                txtLargestCity.setText("Location: Rome, Italy");
                txtLanguage.setText("Built: 70–80 AD");
                txtArea.setText("Capacity: 50,000–80,000 spectators");
                txtCurrency.setText("Type: Amphitheatre");
                txtDescription.setText("The Colosseum is the largest ancient amphitheatre ever built and is still the largest standing amphitheatre in the world today.");
            }

        }, 1500);

        return view;
    }
}
